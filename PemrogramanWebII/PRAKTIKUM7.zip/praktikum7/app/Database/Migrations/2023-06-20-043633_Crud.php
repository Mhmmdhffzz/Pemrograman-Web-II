<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Crud extends Migration
{
    public function up()
    {
        $fields =[
            "id" => [
                "type" => "integer",
                "constraint" => 5,
                "auto_increment" => true
            ],
            "judul" => [
                "type" => "varchar",
                "constraint" => 255,
            ],
            "penulis" => [
                "type" => "varchar",
                "constraint" => 255,
            ],
            "penerbit" => [
                "type" => "varchar",
                "constraint" => 255,
            ],
            "tahun_terbit" => [
                "type" => "year",
            ],
        ];
        $this->forge->addField($fields);
        $this->forge->addKey("id",true);
        $this->forge->createTable("book");
    }

    public function down()
    {
        //
    }
}
