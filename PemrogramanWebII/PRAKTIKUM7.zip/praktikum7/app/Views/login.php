<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .container {
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .form-signin {
            max-width: 400px;
            padding: 30px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.1);
        }

        .form-signin h1 {
            font-size: 28px;
            margin-bottom: 30px;
            color: #333;
            letter-spacing: 1px;
        }

        .form-floating {
            margin-bottom: 25px;
        }

        .form-floating label {
            margin-left: 10px;
            color: #777777;
            font-size: 14px;
        }

        .form-floating input {
            padding: 12px;
            border-radius: 5px;
            border: none;
            background-color: #f9f9f9;
            color: #333;
            font-size: 16px;
        }

        .form-floating input:focus {
            outline: none;
            background-color: #f1f1f1;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
            transition: background-color 0.3s;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <main class="form-signin">
            <form action="<?= base_url('/login') ?>" method="POST">
              <h1 class="h3 mb-3 fw-normal">CRUD Login</h1>
              <?php if(session()->getFlashdata('pesan')):?>
              <div class="alert alert-warning" role="alert">
               <?= session()->getFlashdata('pesan') ?>
             </div>
             <?php endif?>
              <div class="form-floating">
                <input type="text" class="form-control" id="floatingUsername" placeholder="Username" name="username">
                <label for="floatingInput">Username</label>
              </div>
              <div class="form-floating">
                <input type="email" class="form-control" id="floatingInput" placeholder="name@example.com" name="email">
                <label for="floatingInput">Email address</label>
              </div>
              <div class="form-floating">
                <input type="password" class="form-control" id="floatingPassword" placeholder="Password" name="password">
                <label for="floatingPassword">Password</label>
              </div>
          
              
              <button class="w-100 mt-2 btn btn-lg btn-primary" type="submit">Sign in</button>
              
            </form>
        </main>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
</body>
</html>
